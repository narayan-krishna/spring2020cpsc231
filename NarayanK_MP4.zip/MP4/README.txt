Krishna Narayan
2327305
narayan@chapman.edu
CPSC 231: Computer Science II
Mastery Project 4: More Classes

Files submitted:
Pizza.java
PizzaOrder.java
PizzaDriver.java

Compile/runtime errors, code limitations/deviations:
None

References:
zyBooks - Computer Science II
https://way2java.com/java-lang/class-character/java-character-touppercase-method-example/
https://stackoverflow.com/questions/25918532/adding-an-element-to-the-first-empty-arrays-index

Running the Assignment:

To compile Pizza.java, PizzaOrder.java, PizzaDriver.java:

javac Pizza.java
javac PizzaOrder.java
javac PizzaDriver.java

To run PizzaDriver.java (after compiling):

java PizzaDriver
