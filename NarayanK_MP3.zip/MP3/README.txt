Krishna Narayan
2327305
narayan@chapman.edu
CPSC 231: Computer Science II
Mastery Project 3: Javadoc

Files submitted:
StudentRecord.java

Compile/runtime errors, code limitations/deviations:
None

References:
zyBooks - Computer Science II
Blackboard CPSC231-02 Assignments - Dog.java

Running the Assignment:

To run StudentRecord.java-

javac StudentRecord.java
java StudentRecord
