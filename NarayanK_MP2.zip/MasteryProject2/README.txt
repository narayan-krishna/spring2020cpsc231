Krishna Narayan
2327305
narayan@chapman.edu
CPSC 231: Computer Science II
Mastery Project 2: Recursion and Intro to Classes

Files submitted:
Harmonic.java
StudentRecord.java

Compile/runtime errors, code limitations/deviations:
None

References:
zyBooks - Computer Science II

Running the Assignment:

To run Harmonic.java-

javac Harmonic.java
java Harmonic

To run StudentRecord.java-

javac StudentRecord.java
java StudentRecord
