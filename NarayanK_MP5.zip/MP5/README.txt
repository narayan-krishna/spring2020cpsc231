Krishna Narayan
2327305
narayan@chapman.edu
CPSC 231: Computer Science II
Mastery Project 5: Modern War(fare)

Files submitted:
Card.java
Deck.java
Player.java
Game.java
Simulation.java
WarLogger.java

Compile/runtime errors, code limitations/deviations:
None

References:
zyBooks - Computer Science II
https://mkyong.com/java/java-convert-string-to-int/
https://docs.oracle.com/javase/8/docs/api/java/util/Random.html


Running the Assignment:

To compile:

javac Simulation.java

To run Simulation.java (after compiling):

java Simulation **type desired number of games here**
